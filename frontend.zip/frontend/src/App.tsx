import React, { FC } from "react";

const App: FC = () => {
  return <div>web3-boilerplate</div>;
};

export default App;
