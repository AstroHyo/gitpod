# web3-boilerplate

## web3 boilerplate for ReactTS

220106 - first commit
